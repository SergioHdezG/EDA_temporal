package EjercicioPositions;

public class Main {
    public static void main(String[] args) {
        PositionalList<String> lista = new LinkedPositionalList<>();

        lista.addLast("Verstappen");
        lista.addLast("Leclerc");
        lista.addLast("Pérez");
        System.out.println("Lista: " + lista.toString());
        System.out.println("Initial size: " + lista.size());
        System.out.println("First addLast: " + lista.addLast("Russel").getElement());
        System.out.println("Second addLast: " + lista.addLast("Alonso").getElement());
        System.out.println("Third addFirst: " + lista.addFirst("Sainz").getElement());
        System.out.println("Lista: " + lista.toString());
        System.out.println("get(3): " + lista.get(3));
        Position<String> p = lista.getPosition(3);
        System.out.println("p.getElement(3): " + p.getElement());
        Position<String> hamilton = lista.addBefore(p, "Hamilton");
        System.out.println("addBefore(3): " + hamilton.getElement());
        System.out.println("Lista: " + lista.toString());
        System.out.println("addAfter(3): " + lista.addAfter(p, "Bottas").getElement());
        System.out.println("Lista: " + lista.toString());
        System.out.println("Is it empty? " + lista.isEmpty());
        System.out.println("Remove Hamilton: " + lista.remove(hamilton));
        System.out.println("Lista: " + lista.toString());
    }
}