package Ejercicio3;

public class StacksExample {

    public static void main(String[] args) {
        StackInterface<Integer> myArrayStack = new ArrayStack<>();
        StackInterface<Integer> myLinkedStack = new LinkedStack<>();

        myArrayStack.push(1);
        myArrayStack.push(2);
        myArrayStack.push(3);
        System.out.println("--- IntegerArrayStack ---");
        System.out.println("Stack: " + myArrayStack.toString());
        System.out.println("Initial size: " + myArrayStack.size());
        System.out.println("First pop: " + myArrayStack.pop());
        System.out.println("Second pop: " + myArrayStack.pop());
        System.out.println("Third pop: " + myArrayStack.pop());
        System.out.println("Stack: " + myArrayStack.toString());
        System.out.println("Is it empty? " + myArrayStack.isEmpty());
        System.out.println("------------------\n");

        myLinkedStack.push(1);
        myLinkedStack.push(2);
        myLinkedStack.push(3);
        System.out.println("--- LinkedIntegerStack ---");
        System.out.println("Stack: " + myLinkedStack.toString());
        System.out.println("Initial size: " + myLinkedStack.size());
        System.out.println("First pop: " + myLinkedStack.pop());
        System.out.println("Second pop: " + myLinkedStack.pop());
        System.out.println("Third pop: " + myLinkedStack.pop());
        System.out.println("Stack: " + myLinkedStack.toString());
        System.out.println("Is it empty? " + myLinkedStack.isEmpty());
        System.out.println("------------------\n");
           
        /*
        // Código que deberia funcionar con una cola
        QueueInterface<Integer> myArrayQueue = new ArrayQueue<>();
        QueueInterface<Integer> myLinkedQueue = new LinkedQueue<>();

        myArrayQueue.enqueue(1);
        myArrayQueue.enqueue(2);
        myArrayQueue.enqueue(3);
        System.out.println("--- IntegerArrayQueue ---");
        System.out.println("Stack: " + myArrayQueue.toString());
        System.out.println("Initial size: " + myArrayQueue.size());
        System.out.println("First dequeue: " + myArrayQueue.dequeue());
        System.out.println("Second dequeue: " + myArrayQueue.dequeue());
        System.out.println("Third dequeue: " + myArrayQueue.dequeue());
        System.out.println("Stack: " + myArrayQueue.toString());
        System.out.println("Is it empty? " + myArrayQueue.isEmpty());
        System.out.println("------------------\n");

        myLinkedStack.enqueue(1);
        myLinkedStack.enqueue(2);
        myLinkedStack.enqueue(3);
        System.out.println("--- LinkedIntegerQueue ---");
        System.out.println("Stack: " + myLinkedQueue.toString());
        System.out.println("Initial size: " + myLinkedQueue.size());
        System.out.println("First dequeue: " + myLinkedQueue.dequeue());
        System.out.println("Second dequeue: " + myLinkedQueue.dequeue());
        System.out.println("Third dequeue: " + myLinkedQueue.dequeue());
        System.out.println("Stack: " + myLinkedQueue.toString());
        System.out.println("Is it empty? " + myLinkedQueue.isEmpty());
        System.out.println("------------------\n");
*/

    }

}
