package Ejercicio4;

import Ejercicio3.StackInterface;
import Ejercicio3.LinkedStack;

import java.util.Arrays;

public class ReverseMainGenerics {
    /** Tester routine for reversing arrays*/
    public static void main(String args[]) {
            Integer[] a = {4, 5, 14, 16, 41};  //autoboxing allows this
            String[] s = {"Brown", "Rudy", "W. Hernangomez", "Garuba", "J. Hernangomez"};
            System.out.println("a = " + Arrays.toString(a));
            System.out.println("d = " + Arrays.toString(s));
            System.out.println("Reversing...");
            reverse(a);
            reverse(s);
            System.out.println("a = " + Arrays.toString(a));
            System.out.println("d = " + Arrays.toString(s));
    }
    /** A generic method for reversing an array. */
    public static<E> void reverse(E[] a){
        throw new UnsupportedOperationException("not implemented yet.");          
    }
}

