package Ejercicio1_2;

import java.util.Arrays;

public class Ejercicio1Main {
    /** Tester routine for reversing arrays*/
    public static void main(String args[]) {
        int[] a = {4, 5, 14, 16, 41};  //autoboxing allows this
        System.out.println("a = " + Arrays.toString(a));
        System.out.println("Reversing...");
        int[] x = reverse(a);
        System.out.println("a = " + Arrays.toString(x));
    }

    /** A generic method for reversing an array. */
    public static int[] reverse(int[] a){
        throw new UnsupportedOperationException("not implemented yet.");          

    }
}