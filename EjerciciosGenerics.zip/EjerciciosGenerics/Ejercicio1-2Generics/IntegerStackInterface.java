package GenericsExercises.GenericStack;

public interface IntegerStackInterface {
    int size();
    boolean isEmpty();
    Integer top();
    void push(Integer e);
    Integer pop();
    String toString();
}
