/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ReverseList;

import Ejercicio1-2Generics.IntegerStackInterface;
import Ejercicio1-2Generics.GenericStack.ArrayIntegerStack;
import java.util.Arrays;

public class ReverseMain {
    /** Tester routine for reversing arrays*/
    public static void main(String args[]) {
            int[] a = {4, 5, 14, 16, 41};  //autoboxing allows this
            System.out.println("a = " + Arrays.toString(a));
            System.out.println("Reversing...");
            reverse(a);
            System.out.println("a = " + Arrays.toString(a));
    }
    
    /** A method for reversing an array. */
    public static int[] reverse(int[] a){
        throw new UnsupportedOperationException("not implemented yet.");
    }
}

