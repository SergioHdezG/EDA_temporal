package ObjectsSolution;

public interface ObjectList {

    int size();

    boolean isEmpty();

    void add(int i, Object o) throws IndexOutOfBoundsException, IllegalStateException;

    Object remove(int i) throws IndexOutOfBoundsException;

    Object set(int i, Object e) throws IndexOutOfBoundsException;

    Object get(int i) throws IndexOutOfBoundsException;

    String toString();
}
